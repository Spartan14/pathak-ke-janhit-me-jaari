package Demo;

import org.openqa.selenium.By;

public class ElementLocators {
	
	public static By FirstName=By.id("txtFirstName");
	public static By LastName=By.id("txtLastName");
	public static By Email=By.id("txtEmail");
	public static By Phone=By.id("txtPhone");
	public static By Number=By.xpath("//select[@name='size']"); //public static By Number=By.xpath("/html/body/form/table/tbody/tr[5]/td[2]/select/option[3]");
	public static By RoomNo=By.id("txtAddress1");
	public static By AreaName=By.id("txtAddress2");
	public static By City=By.xpath("//select[@name='city']"); //public static By City=By.xpath("/html/body/form/table/tbody/tr[9]/td[2]/select");
	public static By State=By.xpath("//select[@name='state']"); //public static By State=By.xpath("/html/body/form/table/tbody/tr[10]/td[2]/select");
	public static By Member=By.xpath("//select[@name='memberStatus']");//public static By Member=By.name("memberStatus");
	public static By NonMember=By.xpath("//select[@name='memberStatus']");//public static By NonMember=By.name("memberStatus");
	public static By Next=By.linkText("Next");
	public static By HolderName=By.id("txtCardholderName");
	public static By CardNumber=By.id("txtDebit");
	public static By Cvv=By.id("txtCvv");
	public static By ExpMonth=By.id("txtMonth");
	public static By ExpYear=By.id("txtYear");
	public static By MakePayment=By.id("btnPayment");
}
